from django.apps import AppConfig


class FrinetConfig(AppConfig):
    name = 'frinet'
